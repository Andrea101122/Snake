#ifndef GIOCO_H
#define GIOCO_H

#include "Serpente.h"
#include "Cibo.h"

class Gioco {
public:
    Serpente serpente;
    Cibo cibo;
    bool inEsecuzione;
    int punteggio;
    Sound suonoMangia;
    Sound suonoParete;

    Gioco();
    ~Gioco();
    void Disegna();
    void Aggiorna();
    void ControllaCollisioneConCibo();
    void ControllaCollisioneConBordi();
    void GameOver();
    void ControllaCollisioneConCoda();
};
#endif // GIOCO_H