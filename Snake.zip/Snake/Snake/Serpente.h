#ifndef SERPENTE_H
#define SERPENTE_H

#include <deque>
#include "raylib.h"
#include "raymath.h"
using namespace std;

class Serpente {
public:
    deque<Vector2> corpo;
    Vector2 direzione;
    bool aggiungiSegmento;

    Serpente();
    void Disegna(int offset, int dimensioneCella, Color colore);
    void Aggiorna();
    void Resetta();
};

#endif // SERPENTE_H