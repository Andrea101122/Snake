#ifndef CIBO_H
#define CIBO_H
using namespace std;

#include <deque>
#include "raylib.h"
#include "raymath.h"

class Cibo {
public:
    Vector2 GeneraCellaCasuale();
    Vector2 posizione;
    Texture2D texture;

    Cibo(deque<Vector2> corpoSerpente);
    ~Cibo();
    void Disegna(int offset, int dimensioneCella);
    Vector2 GeneraPosizioneCasuale(std::deque<Vector2> corpoSerpente);
};
#endif // CIBO_H