#include "Gioco.h"
using namespace std;

// Costruttore per inizializzare l'audio e caricare i suoni
Gioco::Gioco() : serpente(), cibo(serpente.corpo), inEsecuzione(true), punteggio(0) {
    InitAudioDevice();
    suonoMangia = LoadSound("Sounds/eat.mp3");
    suonoParete = LoadSound("Sounds/wall.mp3");
}

// Distruttore per scaricare i suoni e chiudere il dispositivo audio

Gioco::~Gioco() {
    UnloadSound(suonoMangia);
    UnloadSound(suonoParete);
    CloseAudioDevice();
}

// Funzione per disegnare il serpente e il cibo
void Gioco::Disegna() {
    cibo.Disegna(75, 30);
    serpente.Disegna(75, 30, { 43, 51, 24, 255 });
}

// Funzione per aggiornare lo stato del gioco
void Gioco::Aggiorna() {
    if (inEsecuzione) {
        serpente.Aggiorna();
        ControllaCollisioneConCibo();
        ControllaCollisioneConBordi();
        ControllaCollisioneConCoda();
    }
}

// Funzione per controllare la collisione con il cibo
void Gioco::ControllaCollisioneConCibo() {
    if (Vector2Equals(serpente.corpo[0], cibo.posizione)) {
        cibo.posizione = cibo.GeneraPosizioneCasuale(serpente.corpo);
        serpente.aggiungiSegmento = true;
        punteggio++;
        PlaySound(suonoMangia);
    }
}

// Funzione per controllare la collisione con i bordi
void Gioco::ControllaCollisioneConBordi() {
    if (serpente.corpo[0].x == 25 || serpente.corpo[0].x == -1) {
        GameOver();
    }
    if (serpente.corpo[0].y == 25 || serpente.corpo[0].y == -1) {
        GameOver();
    }
}

// Funzione per gestire la fine del gioco
void Gioco::GameOver() {
    serpente.Resetta();
    cibo.posizione = cibo.GeneraPosizioneCasuale(serpente.corpo);
    inEsecuzione = false;
    punteggio = 0;
    PlaySound(suonoParete);
}

// Funzione per controllare la collisione con la coda del serpente
void Gioco::ControllaCollisioneConCoda() {
    deque<Vector2> corpoSenzaTesta = serpente.corpo;
    corpoSenzaTesta.pop_front();
    if (find(corpoSenzaTesta.begin(), corpoSenzaTesta.end(), serpente.corpo[0]) != corpoSenzaTesta.end()) {
        GameOver();
    }
}