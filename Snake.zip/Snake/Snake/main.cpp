#include <iostream>
#include "raylib.h"
#include "Gioco.h"
using namespace std;

// Variabile per controllare se � permesso il movimento
static bool permetteMossa = false;

// Colori personalizzati
Color verdeChiaro = { 173, 204, 96, 255 };
Color verdeScuro = { 43, 51, 24, 255 };

// Dimensioni della griglia di gioco
int dimensioneCella = 30;
int numeroCelle = 25;
int offset = 75;

// Tempo dell'ultimo aggiornamento
double ultimoTempoAggiornamento = 0;

// Funzione per verificare se � trascorso un intervallo di tempo
bool EventoScatenato(double intervallo) {
    double tempoCorrente = GetTime();
    if (tempoCorrente - ultimoTempoAggiornamento >= intervallo) {
        ultimoTempoAggiornamento = tempoCorrente;
        return true;
    }
    return false;
}

void main() {
    cout << "Avvio del gioco..." << endl;

    // Inizializza la finestra di gioco
    InitWindow(2 * offset + dimensioneCella * numeroCelle, 2 * offset + dimensioneCella * numeroCelle, "Serpente Retro");

    // Imposta il frame rate a 60 FPS
    SetTargetFPS(60);

    // Crea un'istanza del gioco
    Gioco gioco = Gioco();

    // Loop principale del gioco
    while (WindowShouldClose() == false) {
        BeginDrawing();

        // Controlla se � tempo di aggiornare lo stato del gioco
        if (EventoScatenato(0.2)) {
            permetteMossa = true;
            gioco.Aggiorna();
        }

        // Gestione degli input della tastiera per cambiare direzione
        if (IsKeyPressed(KEY_UP) && gioco.serpente.direzione.y != 1 && permetteMossa) {
            gioco.serpente.direzione = { 0, -1 };
            gioco.inEsecuzione = true;
            permetteMossa = false;
        }
        if (IsKeyPressed(KEY_DOWN) && gioco.serpente.direzione.y != -1 && permetteMossa) {
            gioco.serpente.direzione = { 0, 1 };
            gioco.inEsecuzione = true;
            permetteMossa = false;
        }
        if (IsKeyPressed(KEY_LEFT) && gioco.serpente.direzione.x != 1 && permetteMossa) {
            gioco.serpente.direzione = { -1, 0 };
            gioco.inEsecuzione = true;
            permetteMossa = false;
        }
        if (IsKeyPressed(KEY_RIGHT) && gioco.serpente.direzione.x != -1 && permetteMossa) {
            gioco.serpente.direzione = { 1, 0 };
            gioco.inEsecuzione = true;
            permetteMossa = false;
        }

        // Disegno della scena
        ClearBackground(verdeChiaro);
        DrawRectangleLinesEx(Rectangle{ (float)offset - 5, (float)offset - 5, (float)dimensioneCella * numeroCelle + 10, (float)dimensioneCella * numeroCelle + 10 }, 5, verdeScuro);
        DrawText("Serpente Retro", offset - 5, 20, 40, verdeScuro);
        DrawText(TextFormat("%i", gioco.punteggio), offset - 5, offset + dimensioneCella * numeroCelle + 10, 40, verdeScuro);
        gioco.Disegna();

        EndDrawing();
    }
    CloseWindow();
}