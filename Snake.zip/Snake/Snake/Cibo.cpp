#include "Cibo.h"
using namespace std;

// Costruttore per caricare la texture del cibo e generare una posizione casuale
Cibo::Cibo(deque<Vector2> corpoSerpente) {
    Image image = LoadImage("Graphics/food.png");
    texture = LoadTextureFromImage(image);
    UnloadImage(image);
    posizione = GeneraPosizioneCasuale(corpoSerpente);
}

// Distruttore per scaricare la texture del cibo
Cibo::~Cibo() {
    UnloadTexture(texture);
}

// Funzione per disegnare il cibo
void Cibo::Disegna(int offset, int dimensioneCella) {
    DrawTexture(texture, offset + posizione.x * dimensioneCella, offset + posizione.y * dimensioneCella, WHITE);
}

// Funzione per generare una cella casuale
Vector2 Cibo::GeneraCellaCasuale() {
    float x = GetRandomValue(0, 25 - 1);
    float y = GetRandomValue(0, 25 - 1);
}

// Funzione per generare una posizione casuale per il cibo che non si sovrapponga al serpente
Vector2 Cibo::GeneraPosizioneCasuale(deque<Vector2> corpoSerpente) {
    Vector2 posizione = GeneraCellaCasuale();
    while (find(corpoSerpente.begin(), corpoSerpente.end(), posizione) != corpoSerpente.end()) {
        posizione = GeneraCellaCasuale();
    }
    return posizione;
}