#include "Serpente.h"

Serpente::Serpente() {
    corpo = { Vector2{6, 9}, Vector2{5, 9}, Vector2{4, 9} }; // Segmenti iniziali del serpente
    direzione = { 1, 0 }; // Direzione iniziale del serpente
    aggiungiSegmento = false; // Flag per aggiungere un segmento al serpente
}

// Funzione per disegnare il serpente
void Serpente::Disegna(int offset, int dimensioneCella, Color colore) {
    for (unsigned int i = 0; i < corpo.size(); i++) {
        float x = corpo[i].x;
        float y = corpo[i].y;
        Rectangle segmento = Rectangle{ offset + x * dimensioneCella, offset + y * dimensioneCella, (float)dimensioneCella, (float)dimensioneCella };
        DrawRectangleRounded(segmento, 0.5, 6, colore);
    }
}

// Funzione per aggiornare la posizione del serpente
void Serpente::Aggiorna() {
    corpo.push_front(Vector2Add(corpo[0], direzione)); // Aggiunge un nuovo segmento nella direzione corrente
    if (aggiungiSegmento) {
        aggiungiSegmento = false; // Resetta il flag per l'aggiunta del segmento
    }
    else {
        corpo.pop_back(); // Rimuove l'ultimo segmento se non si deve aggiungere un nuovo segmento
    }
}

// Funzione per resettare il serpente alla posizione iniziale
void Serpente::Resetta() {
    corpo = { Vector2{6, 9}, Vector2{5, 9}, Vector2{4, 9} };
    direzione = { 1, 0 };
}